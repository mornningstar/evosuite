package src;

import java.util.Collection;

public interface ActionItem{

	public void perform(Collection arguments);
}
