package src;

interface Player{
//	public void setKills();
//	public void setWounds();
//	public int getKills();
///	public int getWounds();	
	public void setLocation(String location);
	public String getLocation();
	public void kill();
	public void wound();
	public String getRank();
	public void setRank(String rank);
	
}
