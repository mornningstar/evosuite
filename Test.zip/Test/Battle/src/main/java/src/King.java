package src;

public class King {
	
	
}
