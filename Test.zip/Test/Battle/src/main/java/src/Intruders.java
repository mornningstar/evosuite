package src;

public class Intruders implements Player{
	private String location;
	private String type;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Intruders(){
		
	}
	
	public Intruders(String location, String type){
		
	}

	public String getLocation() {
		return this.location;
	}

	public void kill() {
		// TODO Auto-generated method stub
		
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public void wound() {
		// TODO Auto-generated method stub
		
	}

	public String getRank() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setRank(String rank) {
		// TODO Auto-generated method stub
		
	}
}
