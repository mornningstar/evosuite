package src;

public class XMLable {

}
