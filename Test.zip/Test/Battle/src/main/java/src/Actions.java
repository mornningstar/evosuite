package src;

import java.util.Collection;

public class Actions implements ActionItem {

	public void perform(Collection arguments) {

		}
}