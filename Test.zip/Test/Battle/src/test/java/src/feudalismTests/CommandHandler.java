package src.feudalismTests;

public interface CommandHandler {

}
